package com.example.resulto

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ResultoApp()
        }
    }
}

@Composable
fun ResultoApp() {
    var screen by remember { mutableStateOf("home") }

    when (screen) {
        "home" -> HomeScreen(onNavigate = { screen = it })
        "goals" -> GoalsScreen { screen = "home" }
        "timer" -> TimerScreen { screen = "home" }
        "breathing" -> BreathingScreen { screen = "home" }
    }
}

@Composable
fun HomeScreen(onNavigate: (String) -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Resulto") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Button(onClick = { onNavigate("goals") }, modifier = Modifier.fillMaxWidth()) {
                Text("🎯 Цели")
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { onNavigate("timer") }, modifier = Modifier.fillMaxWidth()) {
                Text("⏳ Таймер")
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { onNavigate("breathing") }, modifier = Modifier.fillMaxWidth()) {
                Text("🌬 Дыхание")
            }
        }
    }
}

@Composable
fun GoalsScreen(onBack: () -> Unit) {
    var goals by remember { mutableStateOf(listOf<String>()) }
    var text by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Мои цели") },
                navigationIcon = { Button(onClick = onBack) { Text("←") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("Новая цель") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = {
                if (text.isNotBlank()) {
                    goals = goals + text
                    text = ""
                }
            }) { Text("Добавить") }

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn {
                items(goals.size) { i ->
                    Text("• " + goals[i])
                }
            }
        }
    }
}

@Composable
fun TimerScreen(onBack: () -> Unit) {
    var time by remember { mutableStateOf(25 * 60) }
    var running by remember { mutableStateOf(false) }

    LaunchedEffect(running) {
        while (running && time > 0) {
            delay(1000)
            time -= 1
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Таймер") },
                navigationIcon = { Button(onClick = onBack) { Text("←") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(String.format("%02d:%02d", time / 60, time % 60), style = MaterialTheme.typography.headlineLarge)
            Spacer(modifier = Modifier.height(16.dp))
            Row {
                Button(onClick = { running = !running }) {
                    Text(if (running) "Пауза" else "Старт")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = { time = 25 * 60; running = false }) { Text("Сброс") }
            }
        }
    }
}

@Composable
fun BreathingScreen(onBack: () -> Unit) {
    var phase by remember { mutableStateOf("Вдох") }
    var time by remember { mutableStateOf(4) }

    LaunchedEffect(phase, time) {
        if (time > 0) {
            delay(1000)
            time -= 1
        } else {
            phase = when (phase) {
                "Вдох" -> "Задержка"
                "Задержка" -> "Выдох"
                "Выдох" -> "Вдох"
                else -> "Вдох"
            }
            time = 4
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Дыхание") },
                navigationIcon = { Button(onClick = onBack) { Text("←") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(phase, style = MaterialTheme.typography.headlineLarge)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Осталось: $time сек")
        }
    }
}
